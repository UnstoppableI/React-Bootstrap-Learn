"use client";

import { Form, Row, Col, Card } from "react-bootstrap";

export default function AddCourseForm() {
  return (
    <div style={{ padding: "24px" }}>
      {/* Page Title */}
      <h2
        style={{
          fontSize: "24px",
          fontWeight: "500",
          marginBottom: "24px",
          color: "#333",
        }}
      >
        Add Course
      </h2>

      {/* Course Information Card */}
      <Card
        style={{
          border: "1px solid #e9ecef",
          borderRadius: "12px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
        }}
      >
        <Card.Body style={{ padding: "24px" }}>
          <h3
            style={{
              fontSize: "18px",
              fontWeight: "600",
              marginBottom: "24px",
              color: "#333",
            }}
          >
            Course Information
          </h3>

          <Form>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-4">
                  <Form.Label
                    style={{
                      fontSize: "14px",
                      color: "#666",
                      marginBottom: "8px",
                    }}
                  >
                    Course title
                  </Form.Label>
                  <Form.Control
                    type="text"
                    placeholder=""
                    style={{
                      borderRadius: "8px",
                      padding: "12px 16px",
                      border: "1px solid #dee2e6",
                      fontSize: "14px",
                    }}
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-4">
                  <Form.Label
                    style={{
                      fontSize: "14px",
                      color: "#666",
                      marginBottom: "8px",
                    }}
                  >
                    Course category
                  </Form.Label>
                  <Form.Select
                    style={{
                      borderRadius: "8px",
                      padding: "12px 16px",
                      border: "1px solid #dee2e6",
                      fontSize: "14px",
                      color: "#666",
                    }}
                  >
                    <option>--select category---</option>
                    <option value="1">Programming</option>
                    <option value="2">Design</option>
                    <option value="3">Business</option>
                    <option value="4">Marketing</option>
                  </Form.Select>
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-4">
              <Form.Label
                style={{
                  fontSize: "14px",
                  color: "#666",
                  marginBottom: "8px",
                }}
              >
                Course description
              </Form.Label>
              <Form.Control
                as="textarea"
                rows={4}
                placeholder="describe your course...."
                style={{
                  borderRadius: "8px",
                  padding: "12px 16px",
                  border: "1px solid #dee2e6",
                  fontSize: "14px",
                  resize: "none",
                }}
              />
            </Form.Group>
          </Form>
        </Card.Body>
      </Card>
    </div>
  );
}
