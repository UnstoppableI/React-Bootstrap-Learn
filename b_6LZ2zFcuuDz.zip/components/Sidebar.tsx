"use client";

import { useState } from "react";
import { Nav, Collapse } from "react-bootstrap";
import {
  BsGrid,
  BsSend,
  BsBook,
  BsJournalBookmark,
  BsCollection,
  BsList,
  BsListTask,
  BsGraphUp,
  BsCalendar3,
  BsGear,
  BsChevronDown,
  BsChevronRight,
} from "react-icons/bs";

interface SidebarProps {
  isOpen: boolean;
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const [createItemsOpen, setCreateItemsOpen] = useState(true);

  return (
    <div
      className={`sidebar-container ${isOpen ? "open" : "closed"}`}
      style={{
        width: isOpen ? "260px" : "0",
        minWidth: isOpen ? "260px" : "0",
        backgroundColor: "#fff",
        borderRight: "1px solid #e9ecef",
        height: "100vh",
        position: "fixed",
        left: 0,
        top: 0,
        transition: "all 0.3s ease",
        overflow: "hidden",
        zIndex: 1000,
      }}
    >
      <div style={{ padding: "20px", minWidth: "260px" }}>
        {/* Logo */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            marginBottom: "30px",
          }}
        >
          <BsGrid size={24} />
          <span style={{ fontSize: "22px", fontWeight: "600" }}>lastink</span>
        </div>

        {/* Navigation */}
        <Nav className="flex-column">
          {/* Dashboard */}
          <Nav.Link
            href="#"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              padding: "12px 8px",
              color: "#333",
              borderRadius: "8px",
              marginBottom: "4px",
            }}
            className="sidebar-link"
          >
            <BsGrid size={18} />
            <span>Dashboard</span>
          </Nav.Link>

          {/* Create Items - Collapsible */}
          <div>
            <Nav.Link
              onClick={() => setCreateItemsOpen(!createItemsOpen)}
              aria-controls="create-items-collapse"
              aria-expanded={createItemsOpen}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "12px 8px",
                color: "#333",
                borderRadius: "8px",
                cursor: "pointer",
                marginBottom: "4px",
              }}
              className="sidebar-link"
            >
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <BsSend size={18} />
                <span>Create Items</span>
              </div>
              {createItemsOpen ? (
                <BsChevronDown size={14} />
              ) : (
                <BsChevronRight size={14} />
              )}
            </Nav.Link>
            <Collapse in={createItemsOpen}>
              <div id="create-items-collapse">
                <Nav.Link
                  href="#"
                  style={{
                    paddingLeft: "44px",
                    padding: "10px 8px 10px 44px",
                    color: "#666",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                  }}
                  className="sidebar-sublink"
                >
                  <span style={{ color: "#333" }}>•</span>
                  <span>Create Course</span>
                </Nav.Link>
                <Nav.Link
                  href="#"
                  style={{
                    paddingLeft: "44px",
                    padding: "10px 8px 10px 44px",
                    color: "#666",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                  }}
                  className="sidebar-sublink"
                >
                  <span style={{ color: "#333" }}>•</span>
                  <span>Create Book</span>
                </Nav.Link>
                <Nav.Link
                  href="#"
                  style={{
                    paddingLeft: "44px",
                    padding: "10px 8px 10px 44px",
                    color: "#666",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                  }}
                  className="sidebar-sublink"
                >
                  <span style={{ color: "#333" }}>•</span>
                  <span>Create Bookset</span>
                </Nav.Link>
              </div>
            </Collapse>
          </div>

          {/* Manage Category */}
          <Nav.Link
            href="#"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              padding: "12px 8px",
              color: "#333",
              borderRadius: "8px",
              marginBottom: "4px",
            }}
            className="sidebar-link"
          >
            <BsList size={18} />
            <span>Manage Category</span>
          </Nav.Link>

          {/* Manage Items */}
          <Nav.Link
            href="#"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              padding: "12px 8px",
              color: "#333",
              borderRadius: "8px",
              marginBottom: "4px",
            }}
            className="sidebar-link"
          >
            <BsListTask size={18} />
            <span>Manage Items</span>
          </Nav.Link>

          {/* Registered User */}
          <Nav.Link
            href="#"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              padding: "12px 8px",
              color: "#333",
              borderRadius: "8px",
              marginBottom: "4px",
            }}
            className="sidebar-link"
          >
            <BsGraphUp size={18} />
            <span>Registered User</span>
          </Nav.Link>

          {/* Today Sold */}
          <Nav.Link
            href="#"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              padding: "12px 8px",
              color: "#333",
              borderRadius: "8px",
              marginBottom: "4px",
            }}
            className="sidebar-link"
          >
            <BsCalendar3 size={18} />
            <span>Today Sold</span>
          </Nav.Link>

          {/* Sold History */}
          <Nav.Link
            href="#"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              padding: "12px 8px",
              color: "#333",
              borderRadius: "8px",
              marginBottom: "4px",
            }}
            className="sidebar-link"
          >
            <BsGear size={18} />
            <span>Sold History</span>
          </Nav.Link>
        </Nav>
      </div>
    </div>
  );
}
