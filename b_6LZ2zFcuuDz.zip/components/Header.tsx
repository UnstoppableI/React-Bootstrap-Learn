"use client";

import { Form, InputGroup, Dropdown } from "react-bootstrap";
import { BsSearch, BsBell, BsList, BsSquare } from "react-icons/bs";

interface HeaderProps {
  toggleSidebar: () => void;
}

export default function Header({ toggleSidebar }: HeaderProps) {
  return (
    <header
      style={{
        backgroundColor: "#fff",
        padding: "16px 24px",
        borderBottom: "1px solid #e9ecef",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      {/* Left Section - Menu toggle and Greeting */}
      <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
        <button
          onClick={toggleSidebar}
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            padding: "4px",
          }}
        >
          <BsList size={24} />
        </button>
        <div>
          <h1
            style={{
              fontSize: "20px",
              fontWeight: "400",
              margin: 0,
              color: "#333",
            }}
          >
            Good Morning, <strong>John Doe</strong>
          </h1>
          <p
            style={{
              fontSize: "14px",
              color: "#666",
              margin: 0,
            }}
          >
            Your performance summary this week
          </p>
        </div>
      </div>

      {/* Right Section - Category dropdown, search, notifications, profile */}
      <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
        {/* Category Dropdown */}
        <Dropdown>
          <Dropdown.Toggle
            variant="outline-secondary"
            id="category-dropdown"
            style={{
              borderRadius: "8px",
              padding: "8px 16px",
              fontSize: "14px",
              border: "1px solid #dee2e6",
              backgroundColor: "#fff",
              color: "#333",
            }}
          >
            Select Category
          </Dropdown.Toggle>
          <Dropdown.Menu>
            <Dropdown.Item href="#">Category 1</Dropdown.Item>
            <Dropdown.Item href="#">Category 2</Dropdown.Item>
            <Dropdown.Item href="#">Category 3</Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>

        {/* Rectangle icon */}
        <button
          style={{
            background: "none",
            border: "1px solid #dee2e6",
            borderRadius: "8px",
            padding: "8px",
            cursor: "pointer",
          }}
        >
          <BsSquare size={16} />
        </button>

        {/* Search */}
        <button
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            padding: "4px",
          }}
        >
          <BsSearch size={20} />
        </button>

        {/* Notifications */}
        <button
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            padding: "4px",
            position: "relative",
          }}
        >
          <BsBell size={20} />
        </button>

        {/* Profile Avatar */}
        <div
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            backgroundColor: "#333",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            fontSize: "14px",
            fontWeight: "600",
          }}
        >
          JD
        </div>
      </div>
    </header>
  );
}
